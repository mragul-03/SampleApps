require "test_helper"

class ProductDetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
