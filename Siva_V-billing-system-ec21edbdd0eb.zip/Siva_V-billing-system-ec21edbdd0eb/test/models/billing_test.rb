require "test_helper"

class BillingTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
