require "test_helper"

class PurchaseMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
